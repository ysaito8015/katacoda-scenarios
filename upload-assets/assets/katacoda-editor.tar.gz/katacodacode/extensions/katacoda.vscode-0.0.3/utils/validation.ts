import * as Joi from 'joi';
import * as fs from 'fs';
import * as path from 'path';
import { Scenario } from '../workspace/scenario';
import { UILAYOUT, IMAGEID } from '../workspace/raw-scenario';
import { Course } from '../workspace/course';

export function validateScenario(scenario: Scenario) {
  const index = scenario.rawScenario;
  const scenarioPath = path.dirname(scenario.uri.fsPath);
  if (!Object.keys(index).length) {
    return 'Validation Error: index.json is empty.';
  }
  if (!index.title) {
    return 'Validation Error: Scenario has no title';
  }
  if (!index.details || !index.details.steps || !index.details.steps.length) {
    return 'Validation Error: Scenario has no steps';
  }
  if (!index.environment || !index.environment.uilayout) {
    return 'Validation Error: Scenario has no layout specified';
  }
  if (!(<any>Object).values(UILAYOUT).includes(index.environment.uilayout)) {
    return 'Validation Error: Layout specified in the index.json is not part of the acceptable layouts as specified here: https://katacoda.com/docs/scenarios/layouts';
  }
  if (!index.backend || !index.backend.imageid) {
    return 'Validation Error: Scenario has no environment image';
  }
  if (!(<any>Object).values(IMAGEID).includes(index.backend.imageid)) {
    return 'Validation Error: Image specified in the index.json is not part of the acceptable environment images as specified here: https://katacoda.com/docs/scenarios/environments';
  }
  let specifiedSteps = index.details.steps;
  specifiedSteps = specifiedSteps.map((step: any) => step.text);
  let actualSteps = fs.readdirSync(scenarioPath);
  actualSteps = actualSteps.filter(
    file =>
      file !== 'intro.md' && file !== 'finish.md' && file !== 'index.json' && file !== 'assets'
  );
  if (JSON.stringify(actualSteps.sort()) !== JSON.stringify(specifiedSteps.sort())) {
    return 'Validation Error: The steps specified in the index.json do not match the files in this folder.';
  }
  let specifiedAssets = index.details.assets ? index.details.assets.host01 : [];
  specifiedAssets = specifiedAssets.map((asset: any) => asset.file);
  let actualAssets: any;
  if (fs.existsSync(`${scenarioPath}/assets`)) {
    actualAssets = fs.readdirSync(`${scenarioPath}/assets`);
  } else {
    actualAssets = [];
  }
  if (JSON.stringify(actualAssets.sort()) !== JSON.stringify(specifiedAssets.sort())) {
    return 'Validation Error: The assets specified in the index.json do not match the files in the assets folder.';
  }
  return true;
}

export function validateCourse(course: Course) {
  const pathwayFile = course.uri.fsPath;
  const coursePath = path.join(path.dirname(pathwayFile), course.rawCourse.url);
  if (!fs.existsSync(coursePath)) {
    return 'Validation Error: The url specified in the pathway file does not exist in this workspace';
  }
  const specifiedScenarios = course.rawCourse.courses;
  let actualScenarios = fs.readdirSync(coursePath);
  if (JSON.stringify(specifiedScenarios.sort()) !== JSON.stringify(actualScenarios.sort())) {
    return 'Validation Error: The scenarios specified in the pathway.json files do not match the scenarios in the course folder';
  }
  return true;
}

function onValidation(err: any) {
  return err ? err.message : true;
}

function validateInput(input: string) {
  const schema = Joi.string()
    .required()
    .max(100);
  return Joi.validate(input.trim(), schema, onValidation);
}

export function validateTitle(title: string) {
  return validateInput(title);
}

export function validateDescription(description: string) {
  return description ? validateInput(description) : true;
}

export function validateFriendlyUrl(url: string) {
  url = url.trim();
  const isValidUrl = validateInput(url) === true;
  const errorMessage = `ValidationError: ${url} exists. Please enter a different name.`;
  if (isValidUrl) {
    return fs.existsSync(url) ? errorMessage : true;
  } else {
    return validateInput(url);
  }
}

export function validateNumber(number: number) {
  const schema = Joi.number().required();
  return Joi.validate(number, schema, onValidation);
}

export function validateAsset(path: string) {
  const fileExists = fs.existsSync(path);
  if (fileExists) {
    const stats = fs.statSync(path);
    if (stats.isDirectory()) {
      return 'Validation Error: Asset should be a file and not a directory';
    }
    return stats.size > 1000000
      ? 'Validation Error: File size should not be above 1mb(one mega byte)'
      : true;
  } else {
    return 'Validation Error: This file does not exist, please check that you entered the path correctly';
  }
}
