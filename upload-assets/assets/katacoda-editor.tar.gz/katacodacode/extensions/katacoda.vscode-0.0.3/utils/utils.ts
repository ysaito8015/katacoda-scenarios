import { parse } from "path";

export const kebabCase = (str: string = ""): string => {
    return str.split(/[\-\_\s\t\:\\/?!@#$%^&*()\[\]]/).filter(s => s !== "").map(w => w.toLowerCase()).join('-');
};

export const incrementString = (str: string): string => {
    const incremented = str.replace(/^(.*?)(\d+$)/gi, function (all, $1, $2) {

        return $1 + ++$2;
    });

    if (incremented === str) {
        return str + "1";
    }

    return incremented;
};

export const incrementFileName = (fileName: string, allFiles: string[]): string => {
    allFiles = allFiles.sort();

    let fileBase = parse(fileName).name;
    const ext = parse(fileName).ext;

    for (let i = 0; i < allFiles.length; i++) {

        if (fileBase === parse(allFiles[i]).name) {
            fileBase = incrementString(fileBase);
        }
    }

    return fileBase + ext;
};

export function pushIfUnique<T>(item: T, array: T[], removeFalsy = false, predicate?: (element: T, index?: number, array?: T[]) => boolean): T[] {
    if (removeFalsy && !item) {
        return array;
    }

    if (predicate) {
        if (!array.find(predicate)) {
            array.push(item);
        }
    } else {
        if (array.indexOf(item) === -1) {
            array.push(item);
        }
    }

    return array;
}