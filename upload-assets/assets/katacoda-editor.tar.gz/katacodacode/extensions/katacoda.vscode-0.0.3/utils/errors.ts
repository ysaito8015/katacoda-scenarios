export class CancellationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'CancellationError';
  }
}

export class ValidtionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}
