import * as assert from 'assert';

import * as utils from "../utils/utils";

suite("Utility functions Test", function () {

    test("kebabCase", () => {
        assert.equal("first-case-string", utils.kebabCase("First_Case_String"));
        assert.equal("second-case-string", utils.kebabCase("second case string"));
        assert.equal("third-case-string", utils.kebabCase("Third!!! case!!! STRING!!?"));
    });

    test("incrementString", () => {
        assert.equal("string2", utils.incrementString("string1"));
        assert.equal("string1", utils.incrementString("string"));
        assert.equal("string_10", utils.incrementString("string_9"));
    });

    test("incrementFileName", () => {
        assert.equal("file1.md", utils.incrementFileName("file.md", ["file.md"]));
        assert.equal("file2.md", utils.incrementFileName("file.md", ["file.md", "file1.md", "file3.md"]));
        assert.equal("file.md", utils.incrementFileName("file.md", ["file1.md", "file3.md"]));
        assert.equal("file4.md", utils.incrementFileName("file.md", ["file1.md", "file2.md", "file.md", "file3.md"]));
    });

    test("pushIfUnique", () => {
        assert.deepEqual([1, 2, 3], utils.pushIfUnique(3, [1, 2]));
        assert.deepEqual([2, 3, 4], utils.pushIfUnique(2, [2, 3, 4]));
        assert.deepEqual([3, 4, 5, null], utils.pushIfUnique(null, [3, 4, 5]));
        assert.deepEqual([4, 5, 6], utils.pushIfUnique(null, [4, 5, 6], true));
    });

    test("pushIfUnique manipulate original array", () => {
        const array = [1, 2, 3];
        utils.pushIfUnique(4, array);
        assert.deepEqual([1, 2, 3, 4], array);
    });

    test("pushIfUnique with predicate", () => {
        const alreadyExists = [{ a: 1 }, { a: 2 }, { a: 3 }];
        utils.pushIfUnique({ a: 2 }, alreadyExists, false, (e) => {
            return e.a === 2;
        });
        assert.deepEqual([{ a: 1 }, { a: 2 }, { a: 3 }], alreadyExists, "should not push if predicate ever returns true");

        const doesntExist = [{ a: 1 }, { a: 2 }, { a: 3 }];
        utils.pushIfUnique({ a: 5 }, doesntExist, false, (e) => {
            return e.a === 5;
        });
        assert.deepEqual([{ a: 1 }, { a: 2 }, { a: 3 }, { a: 5 }], doesntExist, "should not push if predicate always returns false");
    });
});