import { RawCourse } from './raw-course';
import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs-extra';
import * as rimraf from 'rimraf';
import { Scenario } from './scenario';
import { quickPick } from '../commands/command-utils';

export class Course {
  rawCourse: RawCourse = {} as RawCourse;
  uri: vscode.Uri;

  constructor(file: vscode.Uri) {
    this.uri = file;
  }

  async fetchData(): Promise<Course> {
    return new Promise<Course>((resolve, reject) => {
      fs.readFile(this.uri.fsPath, 'utf-8', (err, data) => {
        if (err) {
          reject(err);
          throw err;
        }
        this.rawCourse = JSON.parse(data);
        resolve(this);
      });
    });
  }

  async addScenario(scenario: Scenario): Promise<boolean | void> {
    const selectedScenario: string = scenario.rawScenario.title;
    const course = this;
    const courseFolder = path.join(path.dirname(course.uri.fsPath), course.rawCourse.url);
    const scenarioFolder = path.dirname(scenario.uri.fsPath);
    console.log(scenarioFolder);
    const scenarioPath = path.join(courseFolder, path.basename(scenarioFolder));
    const scenarioExists = fs.existsSync(scenarioPath);
    if (scenarioExists) {
      if (scenarioPath === scenarioFolder) {
        throw new Error(`This scenario already exists in this course`);
      }
      const overwrite = await quickPick(['Yes', 'No'], {
        placeHolder: `Overwrite the existing '${scenario.rawScenario.url}' in the course directory?`
      });
      if (overwrite !== 'Yes') {
        return false;
      }
    }

    const copyOrMove = await quickPick(['copy', 'move'], {
      placeHolder: `Do you want to copy or move this step?`
    });
    if (!copyOrMove) {
      throw new Error(`Scenario not added to course`);
    }

    if (scenarioExists) {
      rimraf.sync(scenarioPath);
      course.rawCourse.courses = course.rawCourse.courses.filter(c => c !== selectedScenario);
    }

    if (copyOrMove === 'copy') {
      fs.copySync(scenarioFolder, scenarioPath);
    } else {
      fs.moveSync(scenarioFolder, scenarioPath);
    }
    course.rawCourse.courses.push(scenario.rawScenario.url);
    fs.writeFileSync(course.uri.fsPath, JSON.stringify(course.rawCourse, null, 4));
  }
}
