import { RawScenario } from './raw-scenario';
import * as vscode from 'vscode';
import { readFile } from 'fs';
import * as path from 'path';
import { RawStepNode } from './raw-scenario-node';
import {
  createMarkDownForSteps,
  generateStepsFormat,
  reIndexStepFiles,
  reIndexScenarioJsonSteps
} from '../commands/command-utils';
import * as fs from 'fs-extra';

export class Scenario {
  rawScenario: RawScenario = {} as RawScenario;
  uri: vscode.Uri;

  /**
   * Call fetchData() after construction to initialize the Scenario
   * @param file the vscode.Uri representation of the file on the disc
   */
  constructor(file: vscode.Uri) {
    // @todo check that file is the correct index.json structure
    if (false) {
      throw new Error(`Attempting to create a Scenario instance from an invalid index.json file`);
    }

    this.uri = file;
  }

  /**
   * Fetches the data from the index.json file
   * Must be called before the object is usable
   */
  async fetchData(): Promise<Scenario> {
    return new Promise<Scenario>((resolve, reject) => {
      readFile(this.uri.fsPath, 'utf-8', (err, data) => {
        if (err) {
          reject(err);
          throw err;
        }
        this.rawScenario = JSON.parse(data);
        resolve(this);
      });
    });
  }

  /**
   * Add a step to the Scenerio
   * Changes the index.json and creates the Markdown file for the step
   * @param title the title of the step
   */
  async addStep(numberOfSteps: number): Promise<string> {
    const existingSteps = this.rawScenario.details.steps;
    const startIndex = existingSteps.length + 1;
    const stopIndex = existingSteps.length + numberOfSteps;
    const fileNames: Array<string> = [];
    for (let i = startIndex; i <= stopIndex; i++) {
      fileNames.push(`step${i}`);
    }
    await createMarkDownForSteps(fileNames, path.dirname(this.uri.fsPath));
    const steps = await generateStepsFormat(fileNames);
    this.rawScenario.details.steps = [...this.rawScenario.details.steps, ...steps];
    fs.writeFileSync(this.uri.fsPath, JSON.stringify(this.rawScenario, null, 4));
    return this.uri.fsPath;
  }

  /**
   * Remove steps from the Scenerio
   * Changes the index.json and creates the Markdown file for the step
   * @param title the title of the step
   */
  removeSteps(steps: String[]) {
    const existingSteps = this.rawScenario.details.steps;
    const stepsToDelete = steps.map(step =>
      existingSteps.find(
        existingStep => step.toLowerCase().trim() === existingStep.title.toLowerCase()
      )
    );
    stepsToDelete.forEach(step => {
      if (step) {
        fs.removeSync(`${path.dirname(this.uri.fsPath)}/${step.text}`);
      }
    });
    this.rawScenario.details.steps = this.rawScenario.details.steps.filter(
      existingStep => !stepsToDelete.some(step => !step || step.text === existingStep.text)
    );
    fs.writeFileSync(this.uri.fsPath, JSON.stringify(this.rawScenario, null, 4));
    if (reIndexStepFiles(this) !== false) {
      reIndexScenarioJsonSteps(this);
    }
    return this.uri.fsPath;
  }

  getSteps(): RawStepNode[] {
    return this.rawScenario.details.steps;
  }
}
