interface ScenarioNode {
    text: string;
    courseData?: string;
    code?: string;
}

export interface RawStepNode extends ScenarioNode {
    title: string;
    answer?: string;
    verify?: string;
}

export interface RawIntroFinishNode extends ScenarioNode {
    credits?: string;
}