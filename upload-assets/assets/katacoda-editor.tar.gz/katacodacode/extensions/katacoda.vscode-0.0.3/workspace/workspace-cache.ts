import * as vscode from 'vscode';
import { Scenario } from './scenario';
import { pushIfUnique } from '../utils/utils';
import { Course } from './course';

export class Cache {
  private scenarios: Scenario[] = [];
  private courses: Course[] = [];
  private hasInitialized: boolean = false;
  private scenarioWatcher: vscode.FileSystemWatcher;
  private courseWatcher: vscode.FileSystemWatcher;

  constructor() {
    this.scenarioWatcher = vscode.workspace.createFileSystemWatcher('**/index.json');
    this.courseWatcher = vscode.workspace.createFileSystemWatcher('*-pathway.json');

    this.scenarioWatcher.onDidChange(async e => {
      const index = this.findScenarioIndexByPath(e.fsPath);

      if (index === -1) {
        throw new Error(`Could not find changed scenario ${e.fsPath}`);
      }
      const scenario = new Scenario(e);
      await scenario.fetchData();
      this.scenarios[index] = scenario;
    });

    this.scenarioWatcher.onDidDelete(e => {
      const index = this.findScenarioIndexByPath(e.fsPath);

      if (index === -1) {
        throw new Error(`Could not find deleted scenario ${e.fsPath}`);
      }

      this.scenarios.splice(index, 1);
    });

    this.scenarioWatcher.onDidCreate(async e => {
      this.addScenario(e);
    });

    this.courseWatcher.onDidChange(async e => {
      const index = this.findCourseIndexByPath(e.fsPath);

      if (index === -1) {
        throw new Error(`Could not find changed course ${e.fsPath}`);
      }
      const course = new Course(e);
      await course.fetchData();
      this.courses[index] = course;
    });

    this.courseWatcher.onDidDelete(e => {
      const index = this.findCourseIndexByPath(e.fsPath);

      if (index === -1) {
        throw new Error(`Could not find deleted course ${e.fsPath}`);
      }

      this.courses.splice(index, 1);
    });

    this.courseWatcher.onDidCreate(async e => {
      this.addScenario(e);
    });
  }

  async addScenario(uri: vscode.Uri) {
    const scenario = new Scenario(uri);
    await scenario.fetchData();

    pushIfUnique(scenario, this.scenarios, false, element => {
      return element.uri.fsPath === uri.fsPath;
    });
  }

  async addCourse(uri: vscode.Uri) {
    const course = new Course(uri);
    await course.fetchData;

    pushIfUnique(course, this.courses, false, element => {
      return element.uri.fsPath === uri.fsPath;
    });
  }

  findCourse(title: string): Course | null {
    return (
      this.courses.find(course => {
        return course.rawCourse.title === title;
      }) || null
    );
  }

  findScenario(title: string): Scenario | null {
    return (
      this.scenarios.find(scenerio => {
        return scenerio.rawScenario.title === title;
      }) || null
    );
  }

  findScenarioByPath(fsPath: string): Scenario | null {
    return (
      this.scenarios.find(scenario => {
        return scenario.uri.fsPath === fsPath;
      }) || null
    );
  }

  private findScenarioIndexByPath(fsPath: string): number {
    return this.scenarios.findIndex(scenario => {
      return scenario.uri.fsPath === fsPath;
    });
  }

  private findCourseIndexByPath(fsPath: string): number {
    return this.courses.findIndex(course => {
      return course.uri.fsPath === fsPath;
    });
  }

  private async populateCourses(): Promise<Course[]> {
    const uris = await vscode.workspace.findFiles('*-pathway.json');

    return Promise.all(
      uris.map(uri => {
        const course = new Course(uri);
        return course.fetchData();
      })
    ).then(courses => {
      this.courses = courses;
      return this.courses;
    });
  }

  private async populateScenarios(): Promise<Scenario[]> {
    const uris = await vscode.workspace.findFiles('**/index.json');

    return Promise.all(
      uris.map(uri => {
        const scenario = new Scenario(uri);
        return scenario.fetchData();
      })
    ).then(scenarios => {
      this.scenarios = scenarios;
      this.populateCourses();
      return this.scenarios;
    });
  }

  async getCourses(): Promise<Course[]> {
    return new Promise<Course[]>((resolve, reject) => {
      if (!this.hasInitialized) {
        resolve(this.populateCourses());
        return;
      }
      resolve(this.courses);
    });
  }

  async getScenarios(): Promise<Scenario[]> {
    return new Promise<Scenario[]>((resolve, reject) => {
      if (!this.hasInitialized) {
        resolve(this.populateScenarios());
        return;
      }
      resolve(this.scenarios);
    });
  }

  async populateCache(): Promise<void> {
    this.hasInitialized = true;
    Promise.all([this.populateCourses, this.populateScenarios]);
  }
}
