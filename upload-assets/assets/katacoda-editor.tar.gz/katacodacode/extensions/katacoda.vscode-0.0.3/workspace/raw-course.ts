export interface RawCourse {
  title: string;
  description: string;
  url: string;
  courses: Array<String>;
}
