import { RawStepNode, RawIntroFinishNode } from './raw-scenario-node';

export enum UILAYOUT {
  'Terminal' = 'terminal',
  '2x Terminal Split' = 'terminal-terminal',
  'Editor + Terminal' = 'editor-terminal',
  'Terminal + Editor for the embedded presentation' = 'editor-terminal-split',
  'Terminal + Iframe' = 'terminal-iframe'
}
// @todo ensure that docker swarm and kubernetes cluster has terminal-terminal ui layout
export enum IMAGEID {
  Ubuntu = 'ubuntu',
  Docker = 'docker',
  'Docker Swarm' = 'swarm',
  Kubernetes = 'kubernetes',
  'Kubernetes Cluster' = 'kubernetes-cluster',
  Ansible = 'ansible',
  'Node.js' = 'node',
  Go = 'go',
  'C#' = 'c#',
  '.Net Core' = 'dotnet',
  Java = 'java8',
  Bash = 'bash'
}

export interface RawScenario {
  // file metadata
  url: string;
  title: string;
  difficulty: string;
  time: string;
  details: {
    steps: RawStepNode[];
    intro: RawIntroFinishNode;
    finish: RawIntroFinishNode;
    assets: any;
  };
  environment: {
    uilayout: UILAYOUT;
    hideintro?: boolean;
    hidefinish?: boolean;
    uisettings?:
      | 'reactjs'
      | 'makefile'
      | 'dockerfile'
      | 'dockercompose'
      | 'csharp'
      | 'javascript'
      | 'golang'
      | 'java'
      | 'xml';
    icon?:
      | 'fa-docker'
      | 'fa-weave'
      | 'fa-kubernetes'
      | 'fa-openshift'
      | 'fa-dcos'
      | 'fa-tensorflow'
      | 'fa-runc'
      | 'fa-coreos'
      | 'fa-elixir'
      | 'fa-csharp'
      | 'fa-fsharp'
      | 'fa-rlang'
      | 'fa-golang'
      | 'fa-java'
      | 'fa-node'
      | 'fa-ruby';
    showdashboard?: boolean;
    dashboards?: any;
    uimessage1?: string;
  };
  backend: {
    imageid: IMAGEID;
  };
}
