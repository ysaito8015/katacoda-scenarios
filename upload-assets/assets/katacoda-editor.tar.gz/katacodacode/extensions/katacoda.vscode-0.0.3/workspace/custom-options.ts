export interface CustomOptions {
  validate?: Function | undefined;
  format?: Function | undefined;
}
