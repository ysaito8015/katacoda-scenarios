# Katacoda VS Code README

[Katacoda](https://www.katacoda.com) is an interactive learning and training platform for software developers. The VS Code extension is designed to make it easier to create new scenarios on the platform.

## Snippets

A series of snippets have been created to help with the creation of the scenarios. The autocomplete functionality requires the editor.quickSuggestions.strings setting to be enabled, otherwise, you'll need to press Ctrl+Space.

| Shortcut | Action |
| ---------|------------|
| cmd      | Create a command snippet  |
| cp       | Create a text block that copies to the user's clipboard |
| exe      | Create a command that can be executed on click |
| exeint   | Create a command that can be executed on click. Sends a Ctrl+C before running command |
| key      | Add Keyboard style commands |
| cpledt   | Create code snippet that can be copied to the editor |
| cpl      | Create a code snippet that can be copied to the user's clipboard | 
| kclink      | Create a Katacoda templated link (https://[[HOST_SUBDOMAIN]]-PORT-[[KATACODA_HOST]].environments.katacoda.com)  | 

## Contributing

If you have any thoughts, comments and feedback then please email SpeakToUs@Katacoda.com